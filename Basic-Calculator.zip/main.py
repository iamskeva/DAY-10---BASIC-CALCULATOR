#Calculator

#ADD
def add(num1, num2):
  return num1 + num2

#SUBTRACT

def subtract(num1, num2):
  return num1 - num2

#Multiply

def multiply(num1, num2):
  return num1 * num2

#Divide

def divide(num1, num2):
  return num1 / num2

operation = {
  "+" : add,
  "-" : subtract,
  "*" : multiply,
  "/" : divide
  }

from art import logo
print(logo)

def calculator():
  num1 = float(input("What is the first number?: "))

  for symbol in operation:
    print(symbol)

  should_continue = True
  while should_continue:
    operation_function = input("Pick an operation: ")

    num2 = float(input("What is the next number?: "))

    # calculator_function = operation[operation_function]
    # answer = calculator_function(num1, num2)

    if operation_function == "+":
      answer = add(num1, num2)
    elif operation_function == "-":
      answer = subtract(num1, num2)
    elif operation_function == "*":
      answer = multiply(num1, num2)
    elif operation_function == "/":
      answer = divide(num1, num2)
    else:
      print("Invalid input.")

    print(f"{num1} {operation_function} {num2} = {answer}")

    if input(f"Type 'y' to continue calculating with {answer} or type 'n' to start a new calculation.: ") == "y":
      num1 = answer
      print(num1)
    else:
      should_continue = False
      calculator()


calculator()